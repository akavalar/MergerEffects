costFun <- function(margins,
                    p0)
{
  return((1 - margins)*p0)
}